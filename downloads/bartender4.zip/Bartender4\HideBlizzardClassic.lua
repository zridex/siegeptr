--[[
	Copyright (c) 2009-2022, Hendrik "Nevcairiel" Leppkes < h.leppkes at gmail dot com >
	All rights reserved.
]]
local _, Bartender4 = ...

local WoWClassic = (WOW_PROJECT_ID ~= WOW_PROJECT_MAINLINE)
local WoWBCC = (WOW_PROJECT_ID == WOW_PROJECT_BURNING_CRUSADE_CLASSIC)

if not WoWClassic or WoWBCC then
	return
end

local function hideActionBarFrame(frame, clearEvents, reanchor, noAnchorChanges)
	if frame then
		if clearEvents then
			frame:UnregisterAllEvents()
		end

		if frame.HideBase then
			frame:HideBase()
		else
			frame:Hide()
		end
		frame:SetParent(Bartender4.UIHider)
		if frame.HookScript and not frame.BT4HybridHideHooked then
			frame.BT4HybridHideHooked = true
			frame:HookScript("OnShow", function(self)
				if not InCombatLockdown() then
					self:Hide()
				end
			end)
		end

		-- setup faux anchors so the frame position data returns valid
		if reanchor and not noAnchorChanges then
			local left, right, top, bottom = frame:GetLeft(), frame:GetRight(), frame:GetTop(), frame:GetBottom()
			frame:ClearAllPoints()
			if left and right and top and bottom then
				frame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", left, top)
				frame:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMLEFT", right, bottom)
			else
				frame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", 10, 10)
				frame:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMLEFT", 20, 20)
			end
		elseif not noAnchorChanges then
			frame:ClearAllPoints()
		end
	end
end

local function hideActionButton(button)
	if not button then return end

	button:Hide()
	if button.UnregisterAllEvents then
		button:UnregisterAllEvents()
	end
	if button.SetAttribute then
		button:SetAttribute("statehidden", true)
	end
	if button.HookScript and not button.BT4HybridHideHooked then
		button.BT4HybridHideHooked = true
		button:HookScript("OnShow", function(self)
			if not InCombatLockdown() then
				self:Hide()
			end
		end)
	end
	button.bar = nil
end

local function hideFrameRegions(frame)
	if frame and frame.GetRegions then
		local regions = {frame:GetRegions()}
		for i = 1, #regions do
			if regions[i] and regions[i].Hide then
				regions[i]:Hide()
			end
		end
	end
end

local function hideVisual(frame)
	if frame then
		if frame.Hide then
			frame:Hide()
		end
		if frame.SetParent and Bartender4.UIHider then
			frame:SetParent(Bartender4.UIHider)
		end
		if frame.HookScript then
			frame:HookScript("OnShow", function(self)
				self:Hide()
			end)
		end
	end
end

local function hideMainMenuBarArt(frame)
	if frame then
		hideFrameRegions(frame)

		if frame.GetChildren then
			local children = {frame:GetChildren()}
			for i = 1, #children do
				hideFrameRegions(children[i])
			end
		end
	end
end

local function clearSlideOutOffset(frame)
	if frame and frame.slideOut and frame.slideOut.GetAnimations then
		local animations = {frame.slideOut:GetAnimations()}
		if animations[1] then
			animations[1]:SetOffset(0,0)
		end
	end
end

function Bartender4:HideBlizzard()
	-- Hidden parent frame
	local UIHider = CreateFrame("Frame")
	UIHider:Hide()
	self.UIHider = UIHider

	if MultiBarBottomLeft then MultiBarBottomLeft:SetParent(UIHider) end
	if MultiBarBottomRight then MultiBarBottomRight:SetParent(UIHider) end
	if MultiBarLeft then MultiBarLeft:SetParent(UIHider) end
	if MultiBarRight then MultiBarRight:SetParent(UIHider) end

	-- Hide MultiBar Buttons, but keep the bars alive
	for i=1,12 do
		hideActionButton(_G["ActionButton" .. i])
		hideActionButton(_G["MultiBarBottomLeftButton" .. i])
		hideActionButton(_G["MultiBarBottomRightButton" .. i])
		hideActionButton(_G["MultiBarRightButton" .. i])
		hideActionButton(_G["MultiBarLeftButton" .. i])
		hideActionButton(_G["MultiBar5Button" .. i])
		hideActionButton(_G["MultiBar6Button" .. i])
		hideActionButton(_G["MultiBar7Button" .. i])
	end
	local managedFramePositions = UIPARENT_MANAGED_FRAME_POSITIONS
	if managedFramePositions then
		managedFramePositions["MainMenuBar"] = nil
		managedFramePositions["MainActionBar"] = nil
		managedFramePositions["StanceBarFrame"] = nil
		managedFramePositions["StanceBar"] = nil
		managedFramePositions["PossessBarFrame"] = nil
		managedFramePositions["PossessActionBar"] = nil
		managedFramePositions["MultiCastActionBarFrame"] = nil
		managedFramePositions["PETACTIONBAR_YPOS"] = nil
		managedFramePositions["PetActionBar"] = nil
		managedFramePositions["ExtraAbilityContainer"] = nil
		managedFramePositions["BagsBar"] = nil
		managedFramePositions["MicroMenu"] = nil
	end

	if MainMenuBar then
		hideMainMenuBarArt(MainMenuBar)
		hideActionBarFrame(MainMenuBar, false, true)
		MainMenuBar:EnableMouse(false)
		MainMenuBar:UnregisterEvent("DISPLAY_SIZE_CHANGED")
		MainMenuBar:UnregisterEvent("UI_SCALE_CHANGED")
	end

	hideMainMenuBarArt(MainActionBar)
	hideActionBarFrame(MainActionBar, false, true)


	clearSlideOutOffset(MainMenuBar)

	if OverrideActionBar then -- classic doesn't have this
		clearSlideOutOffset(OverrideActionBar)

		-- when blizzard vehicle is turned off, we need to manually fix the state since the OverrideActionBar animation wont run
		hooksecurefunc("BeginActionBarTransition", function(bar, animIn)
			if bar == OverrideActionBar and not self.db.profile.blizzardVehicle then
				if OverrideActionBar.slideOut then
					OverrideActionBar.slideOut:Stop()
				end
				if MainMenuBar then
					MainMenuBar:Hide()
				end
			end
		end)
	end

	hideMainMenuBarArt(MainMenuBarArtFrame)
	hideActionBarFrame(MainMenuBarArtFrame, false, true)
	hideActionBarFrame(MainMenuBarArtFrameBackground)
	hideActionBarFrame(MicroButtonAndBagsBar, false, false, true)

	hideVisual(MainMenuBarLeftEndCap)
	hideVisual(MainMenuBarRightEndCap)
	hideVisual(MainMenuBarTexture0)
	hideVisual(MainMenuBarTexture1)
	hideVisual(MainMenuBarTexture2)
	hideVisual(MainMenuBarTexture3)
	hideVisual(MainMenuMaxLevelBar0)
	hideVisual(MainMenuMaxLevelBar1)
	hideVisual(MainMenuBarBackpackButton)
	hideVisual(CharacterBag0Slot)
	hideVisual(CharacterBag1Slot)
	hideVisual(CharacterBag2Slot)
	hideVisual(CharacterBag3Slot)

	if KeyRingButton then
		hideActionBarFrame(KeyRingButton, false, false)
	end

	if StatusTrackingBarManager then
		StatusTrackingBarManager:Hide()
		--StatusTrackingBarManager:SetParent(UIHider)
	end

	hideActionBarFrame(StanceBarFrame, true, true)
	hideActionBarFrame(PossessBarFrame, false, true)
	hideActionBarFrame(MultiCastActionBarFrame, false, true)
	hideActionBarFrame(PetActionBarFrame, true, true)
	hideActionBarFrame(StanceBar, true, true)
	hideActionBarFrame(PossessActionBar, true, true)
	hideActionBarFrame(PetActionBar, true, true)
	hideActionBarFrame(MultiBar5, true, true)
	hideActionBarFrame(MultiBar6, true, true)
	hideActionBarFrame(MultiBar7, true, true)
	hideActionBarFrame(BagsBar, true, true)
	hideActionBarFrame(MicroMenu, true, true)
	ShowPetActionBar = function() end

	--BonusActionBarFrame:UnregisterAllEvents()
	--BonusActionBarFrame:Hide()
	--BonusActionBarFrame:SetParent(UIHider)

	if not WoWClassic then
		if PlayerTalentFrame then
			PlayerTalentFrame:UnregisterEvent("ACTIVE_TALENT_GROUP_CHANGED")
		else
			hooksecurefunc("TalentFrame_LoadUI", function() PlayerTalentFrame:UnregisterEvent("ACTIVE_TALENT_GROUP_CHANGED") end)
		end
	end

	hideActionBarFrame(MainMenuBarPerformanceBarFrame, false, false, true)
	hideActionBarFrame(MainMenuExpBar, false, false, true)
	hideActionBarFrame(ReputationWatchBar, false, false, true)
	hideActionBarFrame(MainMenuBarMaxLevelBar, false, false, true)

	if C_AddOns.IsAddOnLoaded("Blizzard_NewPlayerExperience") then
		self:NPE_LoadUI()
	elseif NPE_LoadUI ~= nil then
		self:SecureHook("NPE_LoadUI")
	end
end

function Bartender4:NPE_LoadUI()
	if not (Tutorials and Tutorials.AddSpellToActionBar) then return end

	-- Action Bar drag tutorials
	Tutorials.AddSpellToActionBar:Disable()
	Tutorials.AddClassSpellToActionBar:Disable()

	-- these tutorials rely on finding valid action bar buttons, and error otherwise
	Tutorials.Intro_CombatTactics:Disable()

	-- enable spell pushing because the drag tutorial is turned off
	Tutorials.AutoPushSpellWatcher:Complete()
end
