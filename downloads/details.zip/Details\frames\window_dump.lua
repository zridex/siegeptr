

local Details = _G.Details
local DetailsFramework = _G.DetailsFramework
local C_Timer = _G.C_Timer

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--dump table frame

function Details:DumpTable (t)
	return Details:Dump (t)
end

function Details:DumpInline(t)
	for key, value in pairs(t) do
		print(key, value)
	end
end

function Details:Dump (...)
	if (not DetailsDumpFrame) then
		DetailsDumpFrame = DetailsFramework:CreateSimplePanel(_G.UIParent)
		DetailsDumpFrame = DetailsDumpFrame --[[GLOBAL]]
		DetailsDumpFrame:SetSize(700, 800)
		DetailsDumpFrame:SetTitle("Details! Dump Table [|cFFFF3333Ready Only|r]")

		local text_editor = DetailsFramework:NewSpecialLuaEditorEntry(DetailsDumpFrame, 680, 760, "Editbox", "$parentEntry", true)
		text_editor:SetPoint("topleft", DetailsDumpFrame, "topleft", 10, -30)

		text_editor.scroll:SetBackdrop(nil)
		text_editor.editbox:SetBackdrop(nil)
		text_editor:SetBackdrop(nil)

		DetailsFramework:ReskinSlider(text_editor.scroll)

		if (not text_editor.__background) then
			text_editor.__background = text_editor:CreateTexture(nil, "background")
		end

		text_editor:SetBackdrop({edgeFile = [[Interface\Buttons\WHITE8X8]], edgeSize = 1})
		text_editor:SetBackdropBorderColor(0, 0, 0, 1)

		text_editor.__background:SetColorTexture(0.2317647, 0.2317647, 0.2317647)
		text_editor.__background:SetVertexColor(0.27, 0.27, 0.27)
		text_editor.__background:SetAlpha(0.8)
		text_editor.__background:SetVertTile(true)
		text_editor.__background:SetHorizTile(true)
		text_editor.__background:SetAllPoints()

		local makeClass = function()
			local content = DetailsDumpFrame.Content
			if (type(content) == "table") then
				local widgets = {}

				for memberName, memberValue in pairs(content) do
					local memberType = type(memberValue)
					if (memberType == "number" or memberType == "string" or memberType == "boolean") then
						local sortValue = memberType == "number" and 0 or (memberType == "string" and 1 or 2)
						widgets[#widgets+1] = {name = memberName, type = memberType, value = memberValue, sort = sortValue}

					elseif (memberType == "table") then
						if memberValue.GetObjectType then
							widgets[#widgets+1] = {name = memberName, type = memberType, value = memberValue:GetObjectType(), sort = 4}
						else
							widgets[#widgets+1] = {name = memberName, type = memberType, value = "table", sort = 3}
						end

					elseif (memberType == "function") then
						widgets[#widgets+1] = {name = memberName, type = memberType, value = "fun()", sort = 5}
					end
				end

				table.sort(widgets, function(t1, t2)
					return t1.sort < t2.sort
				end)

				local result = "---@class a : table\n"

				for i = 1, #widgets do
					local widget = widgets[i]
					if (widget.type == "number") then
						result = result .. "---@field " .. widget.name .. " " .. widget.type .. "\n"

					elseif (widget.type == "string") then
						result = result .. "---@field " .. widget.name .. " " .. widget.type .. "\n"

					elseif (widget.type == "boolean") then
						result = result .. "---@field " .. widget.name .. " " .. widget.type .. "\n"

					elseif (widget.type == "table") then
						if widget.value == "table" then
							result = result .. "---@field " .. widget.name .. " table\n"
						else
							result = result .. "---@field " .. widget.name .. " " .. widget.value .. "\n"
						end

					elseif (widget.type == "function") then
						result = result .. "---@field " .. widget.name .. " fun()\n"
					end
				end

				--result = result .. "---@field " .. memberName .. " fun())\n"

				dumpt(result)
			end
		end
		local makeClassButton = DetailsFramework:CreateButton(DetailsDumpFrame, function() makeClass() end, 120, 20, "Make Class", -1, nil, nil, nil, nil, nil, Details.gump:GetTemplate("button", "OPTIONS_BUTTON_TEMPLATE"), Details.gump:GetTemplate("font", "OPTIONS_FONT_TEMPLATE")) --localize-me
		makeClassButton:SetPoint("bottomright", DetailsDumpFrame, "bottomright", -2, 2)
	end

	local t = select(1, ...)
	if (not t) then
		Details:Msg("nothing to show on Dump.")
		return
	else
		if (type(t) == "table") then
			local s = DetailsFramework.table.dump(t)
			DetailsDumpFrame.Editbox:SetText(s)
		else
			t = {...}
			local s = DetailsFramework.table.dump(t)
			DetailsDumpFrame.Editbox:SetText(s)
		end
	end

	DetailsDumpFrame.Content = t
	DetailsDumpFrame:Show()
end



---------------------------------------------------------------------------------------------------------------------------------------
--import export window
--show a window with a big text editor and 2 buttons: okay and cancel.
--cancel button always closes the window and okay calls the comfirm function passed in the argument
--default text is the text shown show the window is show()

function Details:DumpString (text)
	Details:ShowImportWindow (text)
end

function Details:ShowImportWindow (defaultText, confirmFunc, titleText)
	if (not _G.DetailsExportWindow) then
		local importWindow = DetailsFramework:CreateSimplePanel(_G.UIParent, 800, 610, "Details! Dump String", "DetailsExportWindow")
		importWindow:SetFrameStrata("FULLSCREEN")
		importWindow:SetPoint("center")
		DetailsFramework:ApplyStandardBackdrop(importWindow, false, 1.2)

		local importTextEditor = DetailsFramework:NewSpecialLuaEditorEntry(importWindow, 780, 540, "ImportEditor", "$parentEditor", true)
		importTextEditor:SetBackdrop({edgeFile = [[Interface\Buttons\WHITE8X8]], edgeSize = 1, bgFile = [[Interface\Tooltips\UI-Tooltip-Background]], tileSize = 64, tile = true})
		importTextEditor:SetBackdropColor(.2, .2, .2, .5)
		importTextEditor:SetBackdropBorderColor(0, 0, 0, 1)
		importTextEditor:SetPoint("topleft", importWindow, "topleft", 10, -30)

		importTextEditor.scroll:SetBackdrop(nil)
		importTextEditor.editbox:SetBackdrop(nil)
		importTextEditor:SetBackdrop(nil)

		DetailsFramework:ReskinSlider(importTextEditor.scroll)

		if (not importTextEditor.__background) then
			importTextEditor.__background = importTextEditor:CreateTexture(nil, "background")
		end

		importTextEditor:SetBackdrop({edgeFile = [[Interface\Buttons\WHITE8X8]], edgeSize = 1})
		importTextEditor:SetBackdropBorderColor(0, 0, 0, 1)

		importTextEditor.__background:SetColorTexture(0.2317647, 0.2317647, 0.2317647)
		importTextEditor.__background:SetVertexColor(0.27, 0.27, 0.27)
		importTextEditor.__background:SetAlpha(0.8)
		importTextEditor.__background:SetVertTile(true)
		importTextEditor.__background:SetHorizTile(true)
		importTextEditor.__background:SetAllPoints()

		--import button
		local onClickImportButton = function()
			if (_G.DetailsExportWindow.ConfirmFunction) then
				DetailsFramework:Dispatch (_G.DetailsExportWindow.ConfirmFunction, importTextEditor:GetText())
			end
			importWindow:Hide()
		end
		local okayButton = DetailsFramework:CreateButton(importTextEditor, onClickImportButton, 120, 20, "Okay", -1, nil, nil, nil, nil, nil, Details.gump:GetTemplate("button", "OPTIONS_BUTTON_TEMPLATE"), Details.gump:GetTemplate("font", "OPTIONS_FONT_TEMPLATE")) --localize-me
		okayButton:SetIcon ([[Interface\BUTTONS\UI-Panel-BiggerButton-Up]], 20, 20, "overlay", {0.1, .9, 0.1, .9})
		importTextEditor.OkayButton = okayButton

		--cancel button
		local cancelButton = DetailsFramework:CreateButton(importTextEditor, function() importWindow:Hide() end, 120, 20, "Cancel", -1, nil, nil, nil, nil, nil, Details.gump:GetTemplate("button", "OPTIONS_BUTTON_TEMPLATE"), Details.gump:GetTemplate("font", "OPTIONS_FONT_TEMPLATE")) --localize-me
		cancelButton:SetIcon ([[Interface\BUTTONS\UI-Panel-MinimizeButton-Up]], 20, 20, "overlay", {0.1, .9, 0.1, .9})

		okayButton:SetPoint("topright", importTextEditor, "bottomright", 0, -10)
		cancelButton:SetPoint("right", okayButton, "left", -20, 0)

	end

	_G.DetailsExportWindow.ConfirmFunction = confirmFunc
	_G.DetailsExportWindow.ImportEditor:SetText(defaultText or "")
	_G.DetailsExportWindow:Show()

	titleText = titleText or "Details! Dump String"
	_G.DetailsExportWindow.Title:SetText(titleText)

	C_Timer.After(.2, function()
		_G.DetailsExportWindow.ImportEditor:SetFocus(true)
		_G.DetailsExportWindow.ImportEditor.editbox:HighlightText (0)
	end)
end

