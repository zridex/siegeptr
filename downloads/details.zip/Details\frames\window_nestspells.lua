
local hi = "Hello"

