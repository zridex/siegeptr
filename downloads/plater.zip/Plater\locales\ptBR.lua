do
    local addonId = ...
    local languageTable = DetailsFramework.Language.RegisterLanguage(addonId, "ptBR")
    local L = languageTable

------------------------------------------------------------
L["A /reload may be required to take effect."] = "Pode ser necessário um /reload para que tenha efeito."
L["CVar, saved within Plater profile and restored when loading the profile."] = "CVar, salva dentro do perfil do Plater e restaurada ao carregar o perfil."
--[[Translation missing --]]
L["DISABLE_TESTING_AURAS"] = ""
L["EXPORT"] = "Exportar"
L["EXPORT_CAST_COLORS"] = "Compartilhar Cores"
L["EXPORT_CAST_SOUNDS"] = "Compartilhar Sons"
L["HIGHLIGHT_HOVEROVER"] = "Passe o Mouse Sobre o Destaque"
L["HIGHLIGHT_HOVEROVER_ALPHA"] = "Passe o Mouse Sobre o Destaque Alfa"
L["HIGHLIGHT_HOVEROVER_DESC"] = "Destaque os efeitos quando o mouse estiver em cima da placa de identificação."
L["Hold Shift to change the sound of all casts with the audio %s to %s"] = "Mantenha Shift pressionado para alterar o som de todos os lançamentos com o áudio %s para %s"
L["IMPORT"] = "Importar"
L["IMPORT_CAST_COLORS"] = "Importar Cores"
L["IMPORT_CAST_SOUNDS"] = "Importar Sons"
L["OPTIONS_ALPHA"] = "Alpha"
L["OPTIONS_ALPHABYFRAME_ALPHAMULTIPLIER"] = "Multiplicador de transparência."
L["OPTIONS_ALPHABYFRAME_DEFAULT"] = "Transparência Padrão"
L["OPTIONS_ALPHABYFRAME_DEFAULT_DESC"] = "Quantidade de transparência aplicada a todos os componentes de uma única placa de identificação."
L["OPTIONS_ALPHABYFRAME_ENABLE_ENEMIES"] = "Ativar Para Inimigos"
L["OPTIONS_ALPHABYFRAME_ENABLE_ENEMIES_DESC"] = "Aplicar configurações de transparência para unidades inimigas."
L["OPTIONS_ALPHABYFRAME_ENABLE_FRIENDLY"] = "Habilitar para aliados"
L["OPTIONS_ALPHABYFRAME_ENABLE_FRIENDLY_DESC"] = "Aplicar configurações de transparência para unidades aliadas."
L["OPTIONS_ALPHABYFRAME_TARGET_INRANGE"] = "Alvo Alpha/Alcance"
L["OPTIONS_ALPHABYFRAME_TARGET_INRANGE_DESC"] = "Transparência para unidades que estão no alcance ou são o alvo."
L["OPTIONS_ALPHABYFRAME_TITLE_ENEMIES"] = "Quantidade de transparência por quadro (inimigos)"
L["OPTIONS_ALPHABYFRAME_TITLE_FRIENDLY"] = "Quantidade de Transparência por Quadro (amigável)"
L["OPTIONS_AMOUNT"] = "Quantidade"
L["OPTIONS_ANCHOR"] = "Fixar"
L["OPTIONS_ANCHOR_BOTTOM"] = "Inferior"
L["OPTIONS_ANCHOR_BOTTOMLEFT"] = "Inferior Esquerdo"
L["OPTIONS_ANCHOR_BOTTOMRIGHT"] = "Inferior Direito"
L["OPTIONS_ANCHOR_CENTER"] = "Centro"
L["OPTIONS_ANCHOR_INNERBOTTOM"] = "Interno Inferior"
L["OPTIONS_ANCHOR_INNERLEFT"] = "Interno Esquerdo"
L["OPTIONS_ANCHOR_INNERRIGHT"] = "Interno Direita"
L["OPTIONS_ANCHOR_INNERTOP"] = "Interno Superior"
L["OPTIONS_ANCHOR_LEFT"] = "Esquerda"
L["OPTIONS_ANCHOR_RIGHT"] = "Direita"
L["OPTIONS_ANCHOR_TARGET_SIDE"] = "De qual lado esse widget está preso."
L["OPTIONS_ANCHOR_TOP"] = "Superior"
L["OPTIONS_ANCHOR_TOPLEFT"] = "Superior Esquerdo"
L["OPTIONS_ANCHOR_TOPRIGHT"] = "Superior Direito"
L["OPTIONS_AUDIOCUE_COOLDOWN"] = "Áudio do Resfriamento"
L["OPTIONS_AUDIOCUE_COOLDOWN_DESC"] = "Quantidade de tempo em milissegundos de espera antes que o MESMO audio seja tocado novamente.\\n\\nEvita que sons altos sejam reproduzidos quando dois ou mais lançamentos estão acontecendo ao mesmo tempo.\\n\\nDefina para 0 para desabilitar a funcionalidade."
L["OPTIONS_AURA_DEBUFF_HEIGHT"] = "Altura do Ícone de Debuff."
L["OPTIONS_AURA_DEBUFF_WITH"] = "Largura do ícone da penalidade."
L["OPTIONS_AURA_HEIGHT"] = "Altura dos ícones de Debuff's."
L["OPTIONS_AURA_SHOW_BUFFS"] = "Mostrar Buffs"
L["OPTIONS_AURA_SHOW_BUFFS_DESC"] = "Mostrar seus buffs na sua barra pessoal."
L["OPTIONS_AURA_SHOW_DEBUFFS"] = "Mostrar debuffs"
L["OPTIONS_AURA_SHOW_DEBUFFS_DESC"] = "Mostrar seus debuffs na sua barra pessoal."
L["OPTIONS_AURA_WIDTH"] = "Largura dos ícones de Debuff's"
L["OPTIONS_AURAS_ENABLETEST"] = "Habilitar para ocultar as auras de teste mostradas durante a configuração."
L["OPTIONS_AURAS_SORT"] = "Classificar Auras"
L["OPTIONS_AURAS_SORT_DESC"] = "As auras são ordenadas pelo tempo restante (padrão)."
--[[Translation missing --]]
L["OPTIONS_AUTO_ALWAYS_SHOW_IN_ARENA_BG"] = "In Arena / BG"
--[[Translation missing --]]
L["OPTIONS_AUTO_ALWAYS_SHOW_IN_ARENA_BG_DESC"] = "Set 'always show nameplates' on when inside arena or battleground."
--[[Translation missing --]]
L["OPTIONS_AUTO_ALWAYS_SHOW_IN_DUNGEONS"] = "In Dungeons"
--[[Translation missing --]]
L["OPTIONS_AUTO_ALWAYS_SHOW_IN_DUNGEONS_DESC"] = "Set 'always show nameplates' on when inside dungeons."
--[[Translation missing --]]
L["OPTIONS_AUTO_ALWAYS_SHOW_IN_MAJOR_CITIES"] = "In Major Cities"
--[[Translation missing --]]
L["OPTIONS_AUTO_ALWAYS_SHOW_IN_MAJOR_CITIES_DESC"] = "Set 'always show nameplates' on when inside a major city."
--[[Translation missing --]]
L["OPTIONS_AUTO_ALWAYS_SHOW_IN_OPEN_WORLD"] = "In Open World"
--[[Translation missing --]]
L["OPTIONS_AUTO_ALWAYS_SHOW_IN_OPEN_WORLD_DESC"] = "Set 'always show nameplates' on when at any place not listed on the other options."
--[[Translation missing --]]
L["OPTIONS_AUTO_ALWAYS_SHOW_IN_RAID"] = "In Raid"
--[[Translation missing --]]
L["OPTIONS_AUTO_ALWAYS_SHOW_IN_RAID_DESC"] = "Set 'always show nameplates' on when inside raids."
--[[Translation missing --]]
L["OPTIONS_AUTO_ENEMY_IN_ARENA_BG"] = "In Arena / BG"
--[[Translation missing --]]
L["OPTIONS_AUTO_ENEMY_IN_ARENA_BG_DESC"] = "Show enemy nameplates when inside arena or battleground."
--[[Translation missing --]]
L["OPTIONS_AUTO_ENEMY_IN_DUNGEONS"] = "In Dungeons"
--[[Translation missing --]]
L["OPTIONS_AUTO_ENEMY_IN_DUNGEONS_DESC"] = "Show enemy nameplates when inside dungeons."
--[[Translation missing --]]
L["OPTIONS_AUTO_ENEMY_IN_MAJOR_CITIES"] = "In Major Cities"
--[[Translation missing --]]
L["OPTIONS_AUTO_ENEMY_IN_MAJOR_CITIES_DESC"] = "Show enemy nameplates when inside a major city."
--[[Translation missing --]]
L["OPTIONS_AUTO_ENEMY_IN_OPEN_WORLD"] = "In Open World"
--[[Translation missing --]]
L["OPTIONS_AUTO_ENEMY_IN_OPEN_WORLD_DESC"] = "Show enemy nameplates when at any place not listed on the other options."
--[[Translation missing --]]
L["OPTIONS_AUTO_ENEMY_IN_RAID"] = "In Raid"
--[[Translation missing --]]
L["OPTIONS_AUTO_ENEMY_IN_RAID_DESC"] = "Show enemy nameplates when inside raids."
--[[Translation missing --]]
L["OPTIONS_AUTO_ENEMY_NAMEPLATES_IC"] = "Enemy Nameplates in combat"
--[[Translation missing --]]
L["OPTIONS_AUTO_ENEMY_NAMEPLATES_IC_DESC"] = "Automatically enable / disable enemy nameplates in combat."
--[[Translation missing --]]
L["OPTIONS_AUTO_ENEMY_NAMEPLATES_OOC"] = "Enemy Nameplates out of combat"
--[[Translation missing --]]
L["OPTIONS_AUTO_ENEMY_NAMEPLATES_OOC_DESC"] = "Automatically enable / disable enemy nameplates out of combat."
--[[Translation missing --]]
L["OPTIONS_AUTO_FRIENDLY_IN_ARENA_BG"] = "In Arena / BG"
--[[Translation missing --]]
L["OPTIONS_AUTO_FRIENDLY_IN_ARENA_BG_DESC"] = "Show friendly nameplates when inside arena or battleground."
--[[Translation missing --]]
L["OPTIONS_AUTO_FRIENDLY_IN_DUNGEONS"] = "In Dungeons"
--[[Translation missing --]]
L["OPTIONS_AUTO_FRIENDLY_IN_DUNGEONS_DESC"] = "Show friendly nameplates when inside dungeons."
--[[Translation missing --]]
L["OPTIONS_AUTO_FRIENDLY_IN_MAJOR_CITIES"] = "In Major Cities"
--[[Translation missing --]]
L["OPTIONS_AUTO_FRIENDLY_IN_MAJOR_CITIES_DESC"] = "Show friendly nameplates when inside a major city."
--[[Translation missing --]]
L["OPTIONS_AUTO_FRIENDLY_IN_OPEN_WORLD"] = "In Open World"
--[[Translation missing --]]
L["OPTIONS_AUTO_FRIENDLY_IN_OPEN_WORLD_DESC"] = "Show friendly nameplates when at any place not listed on the other options."
--[[Translation missing --]]
L["OPTIONS_AUTO_FRIENDLY_IN_RAID"] = "In Raid"
--[[Translation missing --]]
L["OPTIONS_AUTO_FRIENDLY_IN_RAID_DESC"] = "Show friendly nameplates when inside raids."
--[[Translation missing --]]
L["OPTIONS_AUTO_FRIENDLY_NAMEPLATES_IC"] = "Friendly Nameplates in combat"
--[[Translation missing --]]
L["OPTIONS_AUTO_FRIENDLY_NAMEPLATES_IC_DESC"] = "Automatically enable / disable friendly nameplates in combat."
--[[Translation missing --]]
L["OPTIONS_AUTO_FRIENDLY_NAMEPLATES_OOC"] = "Friendly Nameplates out of combat"
--[[Translation missing --]]
L["OPTIONS_AUTO_FRIENDLY_NAMEPLATES_OOC_DESC"] = "Automatically enable / disable friendly nameplates out of combat."
--[[Translation missing --]]
L["OPTIONS_AUTO_HIDE_BLIZZARD_HEALTHBARS_IC"] = "Hide Blizzard Healthbars in combat"
--[[Translation missing --]]
L["OPTIONS_AUTO_HIDE_BLIZZARD_HEALTHBARS_IC_DESC"] = "Automatically enable / disable showing blizzard nameplate healthbars in combat."
--[[Translation missing --]]
L["OPTIONS_AUTO_HIDE_BLIZZARD_HEALTHBARS_OOC"] = "Hide Blizzard Healthbars out of combat"
--[[Translation missing --]]
L["OPTIONS_AUTO_HIDE_BLIZZARD_HEALTHBARS_OOC_DESC"] = "Automatically enable / disable showing blizzard nameplate healthbars out of combat."
--[[Translation missing --]]
L["OPTIONS_AUTO_HIDE_ENEMY_PETS"] = "Hide Enemy Pets"
--[[Translation missing --]]
L["OPTIONS_AUTO_HIDE_ENEMY_PETS_DESC"] = "Disable show enemy pets within a raid or a dungeon."
--[[Translation missing --]]
L["OPTIONS_AUTO_HIDE_ENEMY_TOTEMS"] = "Hide Enemy Totems"
--[[Translation missing --]]
L["OPTIONS_AUTO_HIDE_ENEMY_TOTEMS_DESC"] = "Disable show enemy totems within a raid or a dungeon."
--[[Translation missing --]]
L["OPTIONS_AUTO_SHOWNAMEPLATE_INCOMBAT"] = "Enable 'Always Show Nameplates' in combat"
--[[Translation missing --]]
L["OPTIONS_AUTO_SHOWNAMEPLATE_INCOMBAT_DESC"] = "Automatically enable / disable the 'always show' option in combat."
--[[Translation missing --]]
L["OPTIONS_AUTO_SHOWNAMEPLATE_OUTOFCOMBAT"] = "Enable 'Always Show Nameplates' out of combat"
--[[Translation missing --]]
L["OPTIONS_AUTO_SHOWNAMEPLATE_OUTOFCOMBAT_DESC"] = "Automatically enable / disable the 'always show' option out of combat."
--[[Translation missing --]]
L["OPTIONS_AUTO_STACKING_IN_ARENA_BG"] = "In Arena / BG"
--[[Translation missing --]]
L["OPTIONS_AUTO_STACKING_IN_ARENA_BG_DESC"] = "Set stacking on when inside arena or battleground."
--[[Translation missing --]]
L["OPTIONS_AUTO_STACKING_IN_DUNGEONS"] = "In Dungeons"
--[[Translation missing --]]
L["OPTIONS_AUTO_STACKING_IN_DUNGEONS_DESC"] = "Set stacking on when inside dungeons."
--[[Translation missing --]]
L["OPTIONS_AUTO_STACKING_IN_MAJOR_CITIES"] = "In Major Cities"
--[[Translation missing --]]
L["OPTIONS_AUTO_STACKING_IN_MAJOR_CITIES_DESC"] = "Set stacking on when inside a major city."
--[[Translation missing --]]
L["OPTIONS_AUTO_STACKING_IN_OPEN_WORLD"] = "In Open World"
--[[Translation missing --]]
L["OPTIONS_AUTO_STACKING_IN_OPEN_WORLD_DESC"] = "Set stacking on when at any place not listed on the other options."
--[[Translation missing --]]
L["OPTIONS_AUTO_STACKING_IN_RAID"] = "In Raid"
--[[Translation missing --]]
L["OPTIONS_AUTO_STACKING_IN_RAID_DESC"] = "Set stacking on when inside raids."
L["OPTIONS_BACKGROUND_ALWAYSSHOW"] = "Sempre Mostrar Fundo"
L["OPTIONS_BACKGROUND_ALWAYSSHOW_DESC"] = "Ativar um fundo que mostra a área da área clicável."
L["OPTIONS_BORDER_COLOR"] = "Cor das Bordas"
L["OPTIONS_BORDER_THICKNESS"] = "Grossura das Bordas"
L["OPTIONS_BUFFFRAMES"] = "Quadros de Buff"
L["OPTIONS_CANCEL"] = "Cancelar"
L["OPTIONS_CAST_COLOR_CHANNELING"] = "Canalizado"
L["OPTIONS_CAST_COLOR_INTERRUPTED"] = "Interrompido"
L["OPTIONS_CAST_COLOR_REGULAR"] = "Regular"
L["OPTIONS_CAST_COLOR_SUCCESS"] = "Sucesso"
L["OPTIONS_CAST_COLOR_UNINTERRUPTIBLE"] = "Ininterrupto"
L["OPTIONS_CAST_SHOW_TARGETNAME"] = "Mostra o Nome do Alvo"
L["OPTIONS_CAST_SHOW_TARGETNAME_DESC"] = "Mostra quem é o alvo do lançamento atual (se o alvo existir)"
L["OPTIONS_CAST_SHOW_TARGETNAME_TANK"] = "[Tanque] Não Mostre Seu Nome"
L["OPTIONS_CAST_SHOW_TARGETNAME_TANK_DESC"] = "   \"Se você é o tanque não mostre o nome do alvo se o lançamento for em v"
L["OPTIONS_CASTBAR_APPEARANCE"] = " = \"Aparência da Barra de Lançam"
L["OPTIONS_CASTBAR_BLIZZCASTBAR"] = "Barra de Lançamento da Blizzard"
L["OPTIONS_CASTBAR_COLORS"] = "Cores da Barra de Lançamento"
L["OPTIONS_CASTBAR_FADE_ANIM_ENABLED"] = "Habilita Esmaecer nas Animações"
L["OPTIONS_CASTBAR_FADE_ANIM_ENABLED_DESC"] = "Habilita animações de esmaecer quando um lançamento inicia e para."
L["OPTIONS_CASTBAR_FADE_ANIM_TIME_END"] = "Na Parada"
L["OPTIONS_CASTBAR_FADE_ANIM_TIME_END_DESC"] = "Quando um lançamento finaliza, isso é a quantidade de tempo que a barra de lançamento leva para passar de 100% de transparência para completamente invisível."
L["OPTIONS_CASTBAR_FADE_ANIM_TIME_START"] = "No Início"
L["OPTIONS_CASTBAR_FADE_ANIM_TIME_START_DESC"] = "Quando um lançamento começa, isso é a quantidade de tempo que a barra de lançamento leva para passar de transparência zero para opaca total."
L["OPTIONS_CASTBAR_HEIGHT"] = "Altura da Barra de Lançamento."
L["OPTIONS_CASTBAR_HIDE_ENEMY"] = "Esconde a Barra de Lançamento de Inimigos"
L["OPTIONS_CASTBAR_HIDE_FRIENDLY"] = "Esconde a Barra de Lançamento de Aliados"
L["OPTIONS_CASTBAR_HIDEBLIZZARD"] = "Ocultar Barra de Lançamento de Jogadores da Blizzard"
L["OPTIONS_CASTBAR_ICON_CUSTOM_ENABLE"] = "Habilita Customização de Ícone"
L["OPTIONS_CASTBAR_ICON_CUSTOM_ENABLE_DESC"] = "Se essa opção for desabilitada, Plater não irá modificar ícones de magia, deixe que os scripts façam isso."
L["OPTIONS_CASTBAR_NO_SPELLNAME_LIMIT"] = "Sem Limitação de Comprimento no Nome do Feitiço"
L["OPTIONS_CASTBAR_NO_SPELLNAME_LIMIT_DESC"] = "Nome do feitiço não será cortado para encaixar na largura da barra de lançamento."
L["OPTIONS_CASTBAR_QUICKHIDE"] = "Ocultação Rápida da Barra de Lançamento"
L["OPTIONS_CASTBAR_QUICKHIDE_DESC"] = "Depois da finalização do lançamento, a barra de lançamento fica oculta imediatamente."
L["OPTIONS_CASTBAR_SPARK_HALF"] = "Meia Faísca"
L["OPTIONS_CASTBAR_SPARK_HALF_DESC"] = "Mostra apenas metade da textura da faísca."
L["OPTIONS_CASTBAR_SPARK_HIDE_INTERRUPT"] = "Esconde Faísca Durante uma Interrupção"
L["OPTIONS_CASTBAR_SPARK_SETTINGS"] = "Configuração de Faísca"
L["OPTIONS_CASTBAR_SPELLICON"] = "Ícone do Feitiço"
L["OPTIONS_CASTBAR_TOGGLE_TEST"] = "Ativa Barra de Lançamento Teste"
L["OPTIONS_CASTBAR_TOGGLE_TEST_DESC"] = "Inicia a barra de lançamento teste, pressione de novo para parar."
L["OPTIONS_CASTBAR_WIDTH"] = "Largura da barra de lançamento."
L["OPTIONS_CASTCOLORS_DISABLE_SOUNDS"] = "Remover todos os sons"
L["OPTIONS_CASTCOLORS_DISABLE_SOUNDS_CONFIRM"] = "Tem certeza de que deseja remover todos os sons de lançamento configurados?"
L["OPTIONS_CASTCOLORS_DISABLECOLORS"] = "Desabilita todas as Cores"
L["OPTIONS_CASTCOLORS_DISABLECOLORS_CONFIRM"] = "Confirmar desativar todas as cores de lançamento?"
L["OPTIONS_CLICK_SPACE_HEIGHT"] = "A altura da área que aceita cliques do mouse para selecionar o alvo."
L["OPTIONS_CLICK_SPACE_WIDTH"] = "A largura da área que aceita cliques do mouse para selecionar o alvo"
L["OPTIONS_COLOR"] = "Cores"
L["OPTIONS_COLOR_BACKGROUND"] = "Cor de Fundo"
L["OPTIONS_CVAR_ENABLE_PERSONAL_BAR"] = "Barras de Vida e Mana Pessoais|cFFFF7700|r"
L["OPTIONS_CVAR_ENABLE_PERSONAL_BAR_DESC"] = [=[Mostra barras de saúde e mana miniaturas abaixo do seu personagem.

    |cFFFF7700[*]|r |cFFa0a0a0CVar, salvo dentro do perfil Plater e restaurado ao carregar o perfil.|r]=]
L["OPTIONS_CVAR_NAMEPLATES_ALWAYSSHOW"] = "Mostrar Sempre Placas de Identificação|cFFFF7700|r"
L["OPTIONS_CVAR_NAMEPLATES_ALWAYSSHOW_DESC"] = [=[Mostra as placas de identificação para todas as unidades próximas. Se desativado, mostra apenas unidades relevantes quando você está em combate.

    |cFFFF7700[*]|r |cFFa0a0a0CVar, salvo no perfil do Plater e restaurado ao carregar o perfil.|r]=]
L["OPTIONS_ENABLED"] = "Habilitar"
L["OPTIONS_ERROR_CVARMODIFY"] = "cvars não podem ser alterados durante o combate."
L["OPTIONS_ERROR_EXPORTSTRINGERROR"] = "Falha ao exportar"
L["OPTIONS_EXECUTERANGE"] = "Alcance de Execução"
L["OPTIONS_EXECUTERANGE_DESC"] = [=[Mostra um indicador quando a unidade alvo está no alcance do 'execute'.

        Se detectar que não está funcionando após um patch, comunique no Discord.]=]
L["OPTIONS_EXECUTERANGE_HIGH_HEALTH"] = "Alcance de Execução (alta cura)"
L["OPTIONS_EXECUTERANGE_HIGH_HEALTH_DESC"] = [=[Mostrar o indicador de execução para a parte alta da vida.

Se a detecção não funcionar após uma atualização, comunique no Discord.]=]
L["OPTIONS_FONT"] = "Fonte"
L["OPTIONS_FORMAT_NUMBER"] = "Formato de Número"
L["OPTIONS_FRIENDLY"] = "Amigável"
L["OPTIONS_GENERALSETTINGS_HEALTHBAR_ANCHOR_TITLE"] = "Aparência da Barra de Vida"
L["OPTIONS_GENERALSETTINGS_HEALTHBAR_BGCOLOR"] = "Barra de Vida: cor de fundo e Alpha"
L["OPTIONS_GENERALSETTINGS_HEALTHBAR_BGTEXTURE"] = "Barra de Vida: Textura de Fundo"
L["OPTIONS_GENERALSETTINGS_HEALTHBAR_TEXTURE"] = "Barra de Vida: Textura"
L["OPTIONS_GENERALSETTINGS_TRANSPARENCY_ANCHOR_TITLE"] = "Transparência é Usada Para"
L["OPTIONS_GENERALSETTINGS_TRANSPARENCY_RANGECHECK"] = "Verificação de Alcance"
L["OPTIONS_GENERALSETTINGS_TRANSPARENCY_RANGECHECK_ALPHA"] = "Alpha"
L["OPTIONS_GENERALSETTINGS_TRANSPARENCY_RANGECHECK_SPEC_DESC"] = "Feitiço para verificação de alcance nesta especialização."
L["OPTIONS_HEALTHBAR"] = "Barra de Vida"
L["OPTIONS_HEALTHBAR_HEIGHT"] = "Altura da Barra de Vida"
L["OPTIONS_HEALTHBAR_SIZE_GLOBAL_DESC"] = [=[Altere o tamanho das placas de identificação do inimigo e do amigável para jogadores e PNJs em combate e fora de combate.

    Cada uma dessas opções pode ser alterada individualmente nas guias NPC Inimigo e Jogador Inimigo.]=]
L["OPTIONS_HEALTHBAR_WIDTH"] = "Largura da Barra de Vida"
L["OPTIONS_HEIGHT"] = "Altura"
L["OPTIONS_HOSTILE"] = "Hostil"
L["OPTIONS_ICON_ELITE"] = "Ícone de Elite"
L["OPTIONS_ICON_ENEMYCLASS"] = "Ícone de Classe do Inimigo"
L["OPTIONS_ICON_ENEMYFACTION"] = "Ícone de Facção Inimiga"
L["OPTIONS_ICON_ENEMYSPEC"] = "Ícone de Especialização do Inimigo"
L["OPTIONS_ICON_FRIENDLY_SPEC"] = "Ícone de Especialização Amigável"
L["OPTIONS_ICON_FRIENDLYCLASS"] = "Classe Aliada"
L["OPTIONS_ICON_FRIENDLYFACTION"] = "Ícone de Facção Amigável"
L["OPTIONS_ICON_PET"] = "Ícone de Mascote"
L["OPTIONS_ICON_QUEST"] = "Ícone de Missão"
L["OPTIONS_ICON_RARE"] = "Ícone de Raro"
L["OPTIONS_ICON_SHOW"] = "Mostrar Ícone"
L["OPTIONS_ICON_SIDE"] = "Mostrar Lateral"
L["OPTIONS_ICON_SIZE"] = "Mostrar Tamanho"
L["OPTIONS_ICON_WORLDBOSS"] = "Ícone de Chefe Mundial"
L["OPTIONS_ICONROWSPACING"] = "Espaçamento de Linha do Ícone"
L["OPTIONS_ICONSPACING"] = "Espaçamento do Ícone"
L["OPTIONS_INDICATORS"] = "Indicadores"
L["OPTIONS_INTERACT_OBJECT_NAME_COLOR"] = "Cor do nome do objeto do jogo"
L["OPTIONS_INTERACT_OBJECT_NAME_COLOR_DESC"] = "Os nomes nos objetos terão esta cor."
L["OPTIONS_INTERRUPT_FILLBAR"] = "Preenche a Barra de lançamento na Interrupção"
L["OPTIONS_INTERRUPT_SHOW_ANIM"] = "Reproduz Animação de Interrupção"
L["OPTIONS_INTERRUPT_SHOW_AUTHOR"] = "Mostra o Autor da Interrupção"
L["OPTIONS_MINOR_SCALE_DESC"] = "Ajuste ligeiramente o tamanho das placas de identificação ao exibir uma unidade menor (essas unidades têm uma placa de identificação menor por padrão)."
L["OPTIONS_MINOR_SCALE_HEIGHT"] = "Escala de Altura de Unidades Menores"
L["OPTIONS_MINOR_SCALE_WIDTH"] = "Escala de Largura de Unidades Menores"
L["OPTIONS_MOVE_HORIZONTAL"] = "Mover horizontalmente."
L["OPTIONS_MOVE_VERTICAL"] = "Mover verticalmente."
L["OPTIONS_NAMEPLATE_HIDE_FRIENDLY_HEALTH"] = "Esconde a Barra de Vida da Blizzard|cFFFF7700*|r"
L["OPTIONS_NAMEPLATE_HIDE_FRIENDLY_HEALTH_DESC"] = [=[Enquanto estiver em masmorras ou raids, se as placas de identificação de aliados ​​estiverem habilitadas, ele mostrará apenas o nome do jogador.
        Se algum modulo do Plater estiver desabilitado, isso irá afetar os efeitos dessas placas de identificação também.

        |cFFFF7700[*]|r |cFFa0a0a0CVar, salvo no perfil do Plater e restaurado quando o perfil é carregado.|r

        |cFFFF2200[*]|r |cFFa0a0a0A /reload pode ser necessario para aplicar os efeitos.|r]=]
L["OPTIONS_NAMEPLATE_OFFSET"] = "Ajuste levemente toda a placa de identificação."
L["OPTIONS_NAMEPLATE_SHOW_ENEMY"] = "Mostrar placas de identificação do Inimigo|cFFFF7700*|r"
L["OPTIONS_NAMEPLATE_SHOW_ENEMY_DESC"] = [=[Mostrar placa de identificação para unidades inimigas e neutras.

|cFFFF7700[]|r |cFFa0a0a0CVar, salva dentro do perfil do Plater e restaurada ao carregar o perfil.|r]=]
L["OPTIONS_NAMEPLATE_SHOW_FRIENDLY"] = "Mostrar placas de identificação Amigáveis|cFFFF7700*|r"
L["OPTIONS_NAMEPLATE_SHOW_FRIENDLY_DESC"] = [=[Mostrar placa de identificação para jogadores amigáveis.

|cFFFF7700[]|r |cFFa0a0a0CVar, salva dentro do perfil do Plater e restaurada ao carregar o perfil.|r]=]
L["OPTIONS_NAMEPLATES_OVERLAP"] = "Sobreposição de Placas de Identificação (V)|cFFFF7700*|r"
L["OPTIONS_NAMEPLATES_OVERLAP_DESC"] = [=[O espaço entre cada placa de identificação verticalmente quando as pilhas estão habilitadas.

|cFFFFFFFFPadrão: 1.10|r

|cFFFF7700[]|r |cFFa0a0a0CVar, salva dentro do perfil do Plater e restaurada ao carregar o perfil.|r

|cFFFFFF00Importante|r: Se você encontrar problemas com essa configuração, use:
|cFFFFFFFF/run SetCVar('nameplateOverlapV', '1.6')|r]=]
L["OPTIONS_NAMEPLATES_STACKING"] = "Pilhas de Placas de Identificação|cFFFF7700*|r"
L["OPTIONS_NAMEPLATES_STACKING_DESC"] = [=[Se ativado, as placas de identificação não se sobrepõem umas às outras.

    |cFFFF7700[*]|r |cFFa0a0a0CVar, salvo dentro do perfil do Plater e restaurado ao carregar o perfil.|r

    |cFFFFFF00Importante |r: para definir a quantidade de espaço entre cada placa de identificação, veja a opção '|cFFFFFFFFPreenchimento Vertical da Placa de Identificação|r' abaixo.
    Verifique as configurações da guia 'Auto' para configurar a alternância automática dessa opção.]=]
L["OPTIONS_NEUTRAL"] = "Neutro"
L["OPTIONS_NOCOMBATALPHA_AMOUNT_DESC"] = "Quantidade de transparência para 'No Combat Alpha'."
L["OPTIONS_NOCOMBATALPHA_ENABLED"] = "Usa Alfa Fora de Combate"
L["OPTIONS_NOCOMBATALPHA_ENABLED_DESC"] = [=[Altere a placa de identificação Alfa quando você está em combate e a unidade não está.

        |cFFFFFF00 Importante |r:se a unidade não estiver em combate, ela sobescreve o alfa do alcance de verificação.]=]
L["OPTIONS_NOESSENTIAL_DESC"] = "Ao atualizar o Plater, é comum que a nova versão também atualize os scripts na área de scripts. Isso pode às vezes, substituir as alterações feitas pelo criador do perfil. A opção abaixo impede que o Plater modifique scripts quando o addon recebe uma atualização. Note: Durante os principais patches e correções de bugs, o Plater ainda pode atualizar os scripts."
L["OPTIONS_NOESSENTIAL_NAME"] = "Desabilita script de atualização não essencial durante atualização de versão do Plater."
L["OPTIONS_NOESSENTIAL_SKIP_ALERT"] = "Ignorar patch não essencial:"
L["OPTIONS_NOESSENTIAL_TITLE"] = "Pular Patches de Script não Essenciais"
L["OPTIONS_NOTHING_TO_EXPORT"] = "Não há nada para exportar."
L["OPTIONS_OKAY"] = "OK"
L["OPTIONS_OUTLINE"] = "Contorno"
L["OPTIONS_PERSONAL_HEALTHBAR_HEIGHT"] = "Altura da barra de vida."
L["OPTIONS_PERSONAL_HEALTHBAR_WIDTH"] = "Largura da barra de vida."
L["OPTIONS_PERSONAL_SHOW_HEALTHBAR"] = "Mostrar barra de vida."
L["OPTIONS_PET_SCALE_DESC"] = "Ajustar ligeiramente o tamanho das placas de identificação ao exibir um mascote"
L["OPTIONS_PET_SCALE_HEIGHT"] = "Escala de Altura do Pet"
L["OPTIONS_PET_SCALE_WIDTH"] = "Escala de Largura do Pet"
L["OPTIONS_PLEASEWAIT"] = "Isso pode levar alguns segundos"
L["OPTIONS_POWERBAR"] = "Barra de Poder"
L["OPTIONS_POWERBAR_HEIGHT"] = "Altura da barra de força."
L["OPTIONS_POWERBAR_WIDTH"] = "Largura da barra de força."
L["OPTIONS_PROFILE_CONFIG_EXPORTINGTASK"] = "Plater está exportando o perfil atual"
L["OPTIONS_PROFILE_CONFIG_EXPORTPROFILE"] = "Exportar Perfil"
L["OPTIONS_PROFILE_CONFIG_IMPORTPROFILE"] = "Importar Perfil"
L["OPTIONS_PROFILE_CONFIG_MOREPROFILES"] = "Obtenha mais perfis no Wago.io"
L["OPTIONS_PROFILE_CONFIG_OPENSETTINGS"] = "Abrir configurações de perfil"
L["OPTIONS_PROFILE_CONFIG_PROFILENAME"] = "Novo nome do perfil"
L["OPTIONS_PROFILE_CONFIG_PROFILENAME_DESC"] = "Um novo perfil é criado com a String importada.  Inserir o nome de um perfil que já existe o substituirá."
L["OPTIONS_PROFILE_ERROR_PROFILENAME"] = "Nome de perfil inválido"
L["OPTIONS_PROFILE_ERROR_STRINGINVALID"] = "Arquivo de perfil inválido."
L["OPTIONS_PROFILE_ERROR_WRONGTAB"] = "Arquivo de perfil inválido. Importe scripts ou mods na guia de scripts/mods."
L["OPTIONS_PROFILE_IMPORT_OVERWRITE"] = "O perfil '%s' já existe, Deseja substituir?"
L["OPTIONS_RANGECHECK_NONE"] = "Nada"
L["OPTIONS_RANGECHECK_NONE_DESC"] = "Nenhuma modificação de alfa foi aplicada."
L["OPTIONS_RANGECHECK_NOTMYTARGET"] = "Unidades Que Não São Seu Alvo"
L["OPTIONS_RANGECHECK_NOTMYTARGET_DESC"] = "Quando uma placa de identificação não é o seu alvo, o alfa é reduzido."
L["OPTIONS_RANGECHECK_NOTMYTARGETOUTOFRANGE"] = "Fora do Alcance + Não é Seu Alvo"
L["OPTIONS_RANGECHECK_NOTMYTARGETOUTOFRANGE_DESC"] = [=[Reduz a transparência das unidades que não são seu alvo.
Reduz ainda mais se a unidade estiver fora de alcance.]=]
L["OPTIONS_RANGECHECK_OUTOFRANGE"] = "Unidades Fora do Seu Alcance"
L["OPTIONS_RANGECHECK_OUTOFRANGE_DESC"] = "Quando uma placa de identificação está fora de alcance, a transparência é reduzida."
L["OPTIONS_RESOURCES_TARGET"] = "Mostrar Recursos no Alvo"
L["OPTIONS_RESOURCES_TARGET_DESC"] = [=[Mostra seus recursos, como pontos de combo, acima do seu alvo atual.
    Usa os recursos padrão do Blizzard e desativa os recursos do Plater.

    Configuração específica do personagem!]=]
L["OPTIONS_SCALE"] = "Escala"
L["OPTIONS_SCRIPTING_ADDOPTION"] = "Selecione quais opções para adicionar"
L["OPTIONS_SCRIPTING_REAPPLY"] = "Aplicar Novamente os Valores Padrão"
L["OPTIONS_SETTINGS_COPIED"] = "configurações copiadas."
L["OPTIONS_SETTINGS_FAIL_COPIED"] = "falha ao obter as configurações da guia selecionada."
L["OPTIONS_SHADOWCOLOR"] = "Cor da Sombra"
L["OPTIONS_SHIELD_BAR"] = "Barra de Escudo"
L["OPTIONS_SHOW_CASTBAR"] = "Mostrar barra de lançamento"
L["OPTIONS_SHOW_POWERBAR"] = "Mostrar barra de força"
L["OPTIONS_SHOWOPTIONS"] = "Mostrar Opções"
L["OPTIONS_SHOWSCRIPTS"] = "Mostrar Scripts"
L["OPTIONS_SHOWTOOLTIP"] = "Mostrar Informações"
L["OPTIONS_SHOWTOOLTIP_DESC"] = "Mostrar informações ao passar o mouse sobre o ícone da aurea."
L["OPTIONS_SIZE"] = "Tamanho."
L["OPTIONS_STACK_AURATIME"] = "Mostrar o tempo mais curto das auras empilhadas"
L["OPTIONS_STACK_AURATIME_DESC"] = "Mostra o tempo mais curto das auras empilhadas ou o tempo mais longo, quando desativado."
L["OPTIONS_STACK_SIMILAR_AURAS"] = "Agrupar Auras Semelhantes"
L["OPTIONS_STACK_SIMILAR_AURAS_DESC"] = "Auras com o mesmo nome (e.g. warlock's unstable affliction debuff) serão empilhadas juntas."
L["OPTIONS_STATUSBAR_TEXT"] = "Agora você pode importar perfis, mods, scripts, animações e tabelas de cores de |cFFFFAA00http://wago.io|r"
L["OPTIONS_TABNAME_ADVANCED"] = "Avançado"
L["OPTIONS_TABNAME_ANIMATIONS"] = "Feedback de feitiços"
L["OPTIONS_TABNAME_AUTO"] = "Automatizações"
L["OPTIONS_TABNAME_BUFF_LIST"] = "Lista de Feitiços"
L["OPTIONS_TABNAME_BUFF_SETTINGS"] = "Buff Config"
L["OPTIONS_TABNAME_BUFF_SPECIAL"] = "Buff Especiais"
L["OPTIONS_TABNAME_BUFF_TRACKING"] = "Rastreamento de Buff"
L["OPTIONS_TABNAME_CASTBAR"] = "Barra de Lançamento"
L["OPTIONS_TABNAME_CASTCOLORS"] = "Nomes e Cores de Cast"
L["OPTIONS_TABNAME_COMBOPOINTS"] = "Pontos de Combo"
L["OPTIONS_TABNAME_GENERALSETTINGS"] = "Config Gerais"
L["OPTIONS_TABNAME_MODDING"] = "Mods"
L["OPTIONS_TABNAME_NPC_COLORNAME"] = "Nomes e Cores de NPCs"
L["OPTIONS_TABNAME_NPCENEMY"] = "NPC Inimigo"
L["OPTIONS_TABNAME_NPCFRIENDLY"] = "NPC Amigo"
L["OPTIONS_TABNAME_PERSONAL"] = "Barra pessoal"
L["OPTIONS_TABNAME_PLAYERENEMY"] = "Jogador Inimigo"
L["OPTIONS_TABNAME_PLAYERFRIENDLY"] = "Jogador Amigo"
L["OPTIONS_TABNAME_PROFILES"] = "Perfis "
L["OPTIONS_TABNAME_SCRIPTING"] = "Scripts"
L["OPTIONS_TABNAME_SEARCH"] = "Pesquisar"
L["OPTIONS_TABNAME_STRATA"] = "Nível e estratos"
L["OPTIONS_TABNAME_TARGET"] = "Alvo"
L["OPTIONS_TABNAME_THREAT"] = "Cores / Aggro"
L["OPTIONS_TEXT_COLOR"] = "A cor do texto."
L["OPTIONS_TEXT_FONT"] = "Fonte do texto."
L["OPTIONS_TEXT_SIZE"] = "Tamanho do texto."
L["OPTIONS_TEXTURE"] = "Textura"
L["OPTIONS_TEXTURE_BACKGROUND"] = "Textura de Fundo"
L["OPTIONS_THREAT_AGGROSTATE_ANOTHERTANK"] = "Aggro em outro Tank"
L["OPTIONS_THREAT_AGGROSTATE_HIGHTHREAT"] = "Ameaça alta"
L["OPTIONS_THREAT_AGGROSTATE_NOAGGRO"] = "Sem Aggro"
L["OPTIONS_THREAT_AGGROSTATE_NOTANK"] = "Sem Aggro nos Tanks"
L["OPTIONS_THREAT_AGGROSTATE_NOTINCOMBAT"] = "Unidade fora de combate"
L["OPTIONS_THREAT_AGGROSTATE_ONYOU_LOWAGGRO"] = "Aggro em você, mas é baixo"
L["OPTIONS_THREAT_AGGROSTATE_ONYOU_LOWAGGRO_DESC"] = "a unidade está atacando você, mas outros podem tomar o Aggro."
L["OPTIONS_THREAT_AGGROSTATE_ONYOU_SOLID"] = "Aggro em Você"
L["OPTIONS_THREAT_AGGROSTATE_TAPPED"] = "Unidade Perdida"
L["OPTIONS_THREAT_CLASSIC_USE_TANK_COLORS"] = "Usa as Cores de Ameaça de Tanque"
L["OPTIONS_THREAT_COLOR_DPS_ANCHOR_TITLE"] = "Cor ao Jogar como DPS ou HEALER"
L["OPTIONS_THREAT_COLOR_DPS_HIGHTHREAT_DESC"] = "A unidade começa a atacar você."
L["OPTIONS_THREAT_COLOR_DPS_NOAGGRO_DESC"] = "A unidade não está atacando você."
L["OPTIONS_THREAT_COLOR_DPS_NOTANK_DESC"] = "A unidade não está atacando você ou outro tank e provavelmente está atacando o Healer ou dps do seu grupo."
L["OPTIONS_THREAT_COLOR_DPS_ONYOU_SOLID_DESC"] = "A unidade está atacando você."
L["OPTIONS_THREAT_COLOR_OVERRIDE_ANCHOR_TITLE"] = "Substituir cores padrão"
L["OPTIONS_THREAT_COLOR_OVERRIDE_DESC"] = "Modifique as cores padrão definidas pelo jogo para unidades neutras, hostis e amigáveis. Durante o combate, essas cores serão substituídas também se as cores de ameaça puderem mudar a cor da barra de saúde."
L["OPTIONS_THREAT_COLOR_TANK_ANCHOR_TITLE"] = "Cor ao Jogar como TANK"
L["OPTIONS_THREAT_COLOR_TANK_ANOTHERTANK_DESC"] = "A unidade está com outro tank do seu grupo."
L["OPTIONS_THREAT_COLOR_TANK_NOAGGRO_DESC"] = "A unidade não tem Aggro em você"
L["OPTIONS_THREAT_COLOR_TANK_NOTINCOMBAT_DESC"] = "A unidade não está em combate."
L["OPTIONS_THREAT_COLOR_TANK_ONYOU_SOLID_DESC"] = "A unidade está atacando você e você tem um aggro sólido."
L["OPTIONS_THREAT_COLOR_TAPPED_DESC"] = "Quando alguém reivindicou a unidade (quando você não recebe experiência ou pilhagem por matá-la)."
L["OPTIONS_THREAT_DPS_CANCHECKNOTANK"] = "Marque para Unidade sem Aggro no Tank"
L["OPTIONS_THREAT_DPS_CANCHECKNOTANK_DESC"] = "Quando você não tem aggro como curandeiro ou dps, verifique se o inimigo está atacando outra unidade que não é um tank."
L["OPTIONS_THREAT_MODIFIERS_ANCHOR_TITLE"] = "Modificações de Aggro"
L["OPTIONS_THREAT_MODIFIERS_BORDERCOLOR"] = "Cor de Borda"
L["OPTIONS_THREAT_MODIFIERS_HEALTHBARCOLOR"] = "Cor da Barra de Vida"
L["OPTIONS_THREAT_MODIFIERS_NAMECOLOR"] = "Cor do Nome"
L["OPTIONS_THREAT_PULL_FROM_ANOTHER_TANK"] = "Puxando Para Outro Tanque"
L["OPTIONS_THREAT_PULL_FROM_ANOTHER_TANK_TANK"] = "A unidade está com aggro em outro tanque e você está prestes a puxar para você."
L["OPTIONS_THREAT_USE_AGGRO_FLASH"] = "Ativa clarão no aggro"
L["OPTIONS_THREAT_USE_AGGRO_FLASH_DESC"] = "Ativa a animação de clarão do -AGGRO- nas placas de identificação ao ganhar o aggro como dps."
L["OPTIONS_THREAT_USE_AGGRO_GLOW"] = "Habilita o brilho do aggro"
L["OPTIONS_THREAT_USE_AGGRO_GLOW_DESC"] = "Habilita o brilho da barra de saúde nas placas de identificação ao ganhar aggro como dps ou perder aggro como tanque."
L["OPTIONS_THREAT_USE_SOLO_COLOR"] = "Cor Solo"
L["OPTIONS_THREAT_USE_SOLO_COLOR_DESC"] = "Usa a cor 'Solo' quando não estiver em grupo."
L["OPTIONS_THREAT_USE_SOLO_COLOR_ENABLE"] = "Usa a cor 'Solo'"
L["OPTIONS_TOGGLE_TO_CHANGE"] = "|cFFFFFF00 Importante |r: ocultar e mostrar as placas de identificação para ver as alterações."
L["OPTIONS_WIDTH"] = "Largura"
L["OPTIONS_XOFFSET"] = "Deslocamento horizontal"
L["OPTIONS_XOFFSET_DESC"] = "Ajuste a posição do eixo X. *clique com botão direito para digitar um valor."
L["OPTIONS_YOFFSET"] = "Deslocamento vertical"
L["OPTIONS_YOFFSET_DESC"] = "Ajuste a posição do eixo Y. *clique com botão direito para digitar um valor."
L[ [=[Show nameplate for friendly npcs.

|cFFFFFF00 Important |r: This option is dependent on the client`s nameplate state (on/off).

|cFFFFFF00 Important |r: when disabled but enabled on the client through (%s), the healthbar isn't visible but the nameplate is still clickable.]=] ] = "Mostrar placa de nome para NPCs amigáveis. |cFFFFFF00 Importante |r: Esta opção depende do estado da placa de nome do cliente (ligada/desligada). |cFFFFFF00 Importante |r: quando desativada mas ativada no cliente através de (%s), a barra de vida não fica visível, mas a placa de nome ainda é clicável."
--[[Translation missing --]]
L[ [=[Show nameplate for friendly npcs.

|cFFFFFF00 Important |r: This option is dependent on the client`s nameplate state (on/off).

|cFFFFFF00 Important |r: when disabled but enabled on the client through (%s), the healthbar isn't visible but the nameplate is still clickable.]=] ] = ""
L["TARGET_CVAR_ALWAYSONSCREEN"] = "Alvo Sempre na Tela|cFFFF7700*|r"
L["TARGET_CVAR_ALWAYSONSCREEN_DESC"] = "Quando habilitado, a placa de identificação do seu alvo é sempre exibida, mesmo que o inimigo não esteja na tela. |cFFFF7700[*]|r |cFFa0a0a0CVar, salvo no perfil do Plater e restaurado quando o perfil é carregado."
L["TARGET_CVAR_LOCKTOSCREEN"] = "Bloqueio de Tela (Lado Superior)|cFFFF7700*|r"
L["TARGET_CVAR_LOCKTOSCREEN_DESC"] = "Espaço mínimo entre as placas de identificação e o topo da tela. Aumente se alguma parte das placa identificadora estiver ficando fora da tela.    |cFFFFFFFFDefault: 0.065   |cFFFFFF00 Important |r: se você tiver problemas, defina manualmente usando essas macro: /run SetCVar ('nameplateOtherTopInset', '0.065)  /run SetCVar ('nameplateLargeTopInset', '0.065) |cFFFFFF00 Importante |r: configurar para 0 desabilita essa funcionalidad. |cFFFF7700[*]|r |cFFa0a0a0CVar, salvo no perfil do Plater e restaurado quando o perfil é carregado"
L["TARGET_HIGHLIGHT"] = " Destaque do Alvo"
L["TARGET_HIGHLIGHT_ALPHA"] = "Destaque Alfa do Alvo"
L["TARGET_HIGHLIGHT_COLOR"] = "Cor de Destaque do Alvo"
L["TARGET_HIGHLIGHT_DESC"] = "Destaque os efeitos da placa de identificação do seu alvo atual."
L["TARGET_HIGHLIGHT_SIZE"] = "Tamanho do Destaque do Alvo"
L["TARGET_HIGHLIGHT_TEXTURE"] = "Textura de Destaque do Alvo"
L["TARGET_OVERLAY_ALPHA"] = "Textura de Sobreposição Alfa"
L["TARGET_OVERLAY_TEXTURE"] = "Textura de Sobreposição de Alvo"
L["TARGET_OVERLAY_TEXTURE_DESC"] = "Usado acima da barra de saúde quando é o alvo atual."

end