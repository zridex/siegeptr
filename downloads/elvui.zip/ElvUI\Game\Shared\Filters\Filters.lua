local E, L, V, P, G = unpack(ElvUI)

local next = next
local unpack = unpack

E.Filters = {}
E.Filters.Included = {}

E.Filters.List = function(priority, enable, stackThreshold)
	return {
		priority = priority or 0,
		enable = enable == nil or enable,
		stackThreshold = stackThreshold or 0
	}
end

E.Filters.Aura = function(auraID, includeIDs, enabled, point, color, anyUnit, onlyShowMissing, displayText, xOffset, yOffset)
	local r, g, b = 1, 1, 1
	if color then
		r, g, b = unpack(color)
	end

	if includeIDs then
		local included = E.Filters.Included
		for _, spellID in next, includeIDs do
			included[spellID] = auraID
		end
	end

	return {
		id = auraID,
		includeIDs = includeIDs,
		enabled = enabled,
		point = point or 'TOPLEFT',
		color = { r = r, g = g, b = b },
		anyUnit = anyUnit or false,
		onlyShowMissing = onlyShowMissing or false,
		displayText = displayText or false,
		xOffset = xOffset or 0,
		yOffset = yOffset or 0,
		style = 'coloredIcon',
		sizeOffset = 0,
		cooldownAnchor = 'CENTER',
		cooldownX = 1,
		cooldownY = 1,
		countAnchor = 'BOTTOMRIGHT',
		countX = 1,
		countY = 1
	}
end

E.Filters.Expand = function(output, source)
	output = output or {}

	for auraID, auraInfo in next, source do
		if auraInfo.includeIDs then
			for _, spellID in next, auraInfo.includeIDs do
				output[spellID] = source[auraID]
			end
		end
		output[auraID] = source[auraID]
	end

	return output
end

-- Profile specific BuffIndicator
P.unitframe.filters = {
	aurawatch = {},
}

G.unitframe.aurafilters = {}

G.unitframe.specialFilters = {
	Boss = true,
	Mount = true,
	MyPet = true,
	OtherPet = true,
	Personal = true,
	NoDuration = true,
	NonPersonal = true,
	CastByUnit = true,
	NotCastByUnit = true,
	Dispellable = true,
	NotDispellable = true,
	CastByNPC = true,
	CastByPlayers = true,
	BlizzardNameplate = true,
}
