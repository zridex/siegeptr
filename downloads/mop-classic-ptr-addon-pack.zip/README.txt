This old siegeptr download path is no longer used.
Please use https://siegeptr.pages.dev/ for the current separate addon downloads.
